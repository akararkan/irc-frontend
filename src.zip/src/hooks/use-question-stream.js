import { questionStreamUrl } from '@/features/qna/qna.api'
import { useSseStream } from '@/hooks/use-sse-stream'

// QnaRealtimeEventType values broadcast on `/api/v1/questions/{id}/stream`.
// Mirrors the post-stream contract: each one becomes a named SSE listener.
//
// Append new types here when the backend grows them — the existing
// handler-routing logic picks them up automatically.
export const QUESTION_REALTIME_EVENTS = [
  'QUESTION_UPDATED',
  'QUESTION_DELETED',
  'QUESTION_LOCKED',
  'QUESTION_UNLOCKED',
  'ANSWER_CREATED',
  'REANSWER_CREATED',
  'ANSWER_EDITED',
  'ANSWER_DELETED',
  'ANSWER_ACCEPTED',
  'ANSWER_UNACCEPTED',
  // Reactions are single-LIKE (Instagram heart). Backend no longer
  // emits ANSWER_REACTION_CHANGED — only ADDED / REMOVED.
  'ANSWER_REACTION_ADDED',
  'ANSWER_REACTION_REMOVED',
  'ANSWER_FEEDBACK_ADDED',
  'ANSWER_FEEDBACK_EDITED',
  'ANSWER_FEEDBACK_DELETED',
  // Multi-scholar best-answer voting — payload includes the fresh
  // `bestAnswerVoteCount` so subscribers update the badge instantly,
  // plus `answerId` and `voterId` for granular UI updates.
  'BEST_ANSWER_VOTED',
  'BEST_ANSWER_UNVOTED',
  // Live view counter — payload carries `questionViewCount` (matches
  // QnaRealtimeEvent#questionViewCount). Fires once per dedupe window
  // per viewer (Redis SET NX EX, 1h) so the count moves at the same
  // rate as the post / research view broadcasts.
  'VIEW_COUNT_UPDATED',
  // Save / bookmark counter — payload carries `questionSaveCount`.
  // Fires on every save/unsave (idempotent on the server side, but
  // only emits when the state actually changed).
  'SAVE_COUNT_UPDATED',
]

/**
 * Subscribe to a question's realtime SSE stream.
 *
 * `handlers` map QnaRealtimeEventType → callback, plus an optional
 * catch-all `onEvent(type, payload)`. `enabled: false` stands the
 * connection down without unmounting the host component.
 */
export function useQuestionStream(questionId, handlers, { enabled = true } = {}) {
  return useSseStream(questionId, handlers, {
    urlBuilder: questionStreamUrl,
    eventNames: QUESTION_REALTIME_EVENTS,
    enabled,
  })
}
