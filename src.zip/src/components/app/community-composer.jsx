import { forwardRef, useImperativeHandle, useState } from 'react'
import {
  Bold,
  ChevronDown,
  Code,
  FileText,
  Globe,
  Hash,
  Image as ImageIcon,
  Italic,
  Link as LinkIcon,
  List,
  Lock,
  Mic,
  Quote,
  Users,
  Video,
} from 'lucide-react'

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { PostComposer } from '@/components/app/post-composer'
import { UserAvatar } from '@/components/app/user-avatar'
import { useAuth } from '@/features/auth/auth-context'
import { cn } from '@/lib/utils'
import { getFullName } from '@/lib/format'

const VISIBILITY = [
  { value: 'PUBLIC', label: 'Public', icon: Globe },
  { value: 'FOLLOWERS_ONLY', label: 'Followers', icon: Users },
  { value: 'ONLY_ME', label: 'Only me', icon: Lock },
]

// Editor toolbar — purely decorative trigger buttons. Click any of
// them and the full PostComposer dialog opens in TEXT mode so the
// user can actually compose. Matches the editorial test-ui composer
// (B I 99 </> link list LaTeX).
const TOOLBAR = [
  { id: 'bold', icon: Bold, label: 'Bold' },
  { id: 'italic', icon: Italic, label: 'Italic' },
  { id: 'quote', icon: Quote, label: 'Quote' },
  { id: 'code', icon: Code, label: 'Code' },
  { id: 'link', icon: LinkIcon, label: 'Link' },
  { id: 'list', icon: List, label: 'List' },
]

// Attach pills — each routes the dialog to a relevant post-type. The
// labels mirror the test-ui design (Paper / Figure / Link / Tag).
const ATTACHMENTS = [
  { id: 'paper', icon: FileText, label: 'Paper', postType: 'EMBEDDED' },
  { id: 'figure', icon: ImageIcon, label: 'Figure', postType: 'EMBEDDED' },
  { id: 'video', icon: Video, label: 'Video', postType: 'REEL' },
  { id: 'voice', icon: Mic, label: 'Voice', postType: 'VOICE_POST' },
  { id: 'tag', icon: Hash, label: 'Tag', postType: 'TEXT' },
]

export const CommunityComposer = forwardRef(function CommunityComposer(
  { onPosted },
  ref,
) {
  const { user } = useAuth()
  const [open, setOpen] = useState(false)
  const [startType, setStartType] = useState('TEXT')
  const [visibility, setVisibility] = useState('PUBLIC')

  useImperativeHandle(
    ref,
    () => ({
      openWith(postType) {
        setStartType(postType ?? 'TEXT')
        setOpen(true)
      },
    }),
    [],
  )

  if (!user) return null

  function trigger(postType = 'TEXT') {
    setStartType(postType)
    setOpen(true)
  }

  const activeVisibility =
    VISIBILITY.find((v) => v.value === visibility) ?? VISIBILITY[0]
  const VisibilityIcon = activeVisibility.icon

  const audienceLine =
    visibility === 'FOLLOWERS_ONLY'
      ? 'POSTING TO FOLLOWERS · VISIBLE TO FOLLOWERS'
      : visibility === 'ONLY_ME'
        ? 'POSTING PRIVATELY · VISIBLE TO YOU ONLY'
        : 'POSTING TO FOLLOWERS · VISIBLE TO ANYONE'

  return (
    <>
      <section className="rounded-xl border-[0.5px] border-border bg-paper">
        {/* ── Author + visibility row ─────────────────────────── */}
        <div className="flex items-start gap-3 px-6 pt-5">
          <UserAvatar user={user} className="size-10 shrink-0" />
          <div className="min-w-0 flex-1 leading-tight">
            <p className="truncate text-[14px] font-medium text-ink">
              {getFullName(user) || 'You'}
            </p>
            <p className="mt-1 truncate font-mono text-[10.5px] uppercase tracking-[0.1em] text-ink-4">
              {audienceLine}
            </p>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                className="inline-flex items-center gap-1.5 rounded-md border-[0.5px] border-border bg-paper px-3 py-1.5 text-[12.5px] text-ink-2 transition-colors hover:bg-secondary"
              >
                <VisibilityIcon className="size-3.5" strokeWidth={1.5} />
                {activeVisibility.label}
                <ChevronDown className="size-3 opacity-60" strokeWidth={1.5} />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              {VISIBILITY.map((option) => {
                const ItemIcon = option.icon
                return (
                  <DropdownMenuItem
                    key={option.value}
                    onSelect={() => setVisibility(option.value)}
                    className={cn(
                      option.value === visibility && 'font-medium text-ink',
                    )}
                  >
                    <ItemIcon className="mr-2 size-4" strokeWidth={1.5} />
                    {option.label}
                  </DropdownMenuItem>
                )
              })}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* ── Title placeholder — italic serif, click to open ── */}
        <button
          type="button"
          onClick={() => trigger('TEXT')}
          className="block w-full px-6 pt-5 text-left"
        >
          <span className="font-display block text-[26px] italic leading-[1.15] tracking-[-0.01em] text-ink-4 transition-colors hover:text-ink-3">
            Give your note a title…
          </span>
        </button>

        {/* ── Body prompt ──────────────────────────────────────── */}
        <button
          type="button"
          onClick={() => trigger('TEXT')}
          className="mt-4 block w-full px-6 text-left"
        >
          <span className="font-display block text-[15.5px] leading-[1.6] text-ink-2">
            What did you read, run, or wonder about today?
          </span>
          <span className="font-display mt-2 block text-[13px] italic leading-[1.5] text-ink-4">
            Mention people with <span className="font-mono not-italic">@</span>, tag fields with{' '}
            <span className="font-mono not-italic">#</span>, attach a paper or notebook below.
          </span>
        </button>

        {/* ── Toolbar + char count ────────────────────────────── */}
        <div className="mx-6 mt-5 flex items-center justify-between border-t-[0.5px] border-border pt-3">
          <div className="flex items-center gap-0.5">
            {TOOLBAR.map((tool) => {
              const Icon = tool.icon
              return (
                <button
                  key={tool.id}
                  type="button"
                  onClick={() => trigger('TEXT')}
                  title={tool.label}
                  aria-label={tool.label}
                  className="grid size-8 place-items-center rounded-md text-ink-3 transition-colors hover:bg-secondary hover:text-ink"
                >
                  <Icon className="size-[15px]" strokeWidth={1.6} />
                </button>
              )
            })}
            <button
              type="button"
              onClick={() => trigger('TEXT')}
              title="LaTeX"
              className="ml-1 grid h-8 place-items-center rounded-md px-2 font-mono text-[12px] italic text-ink-3 transition-colors hover:bg-secondary hover:text-ink"
            >
              ƒx LaTeX
            </button>
          </div>
          <p className="font-mono text-[11px] tabular-nums text-ink-4">
            0 / 4 000
          </p>
        </div>

        {/* ── Attach pills ─────────────────────────────────────── */}
        <div className="mx-6 mt-4 flex flex-wrap items-center gap-2">
          <span className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-ink-4">
            Attach
          </span>
          {ATTACHMENTS.map((att) => {
            const Icon = att.icon
            return (
              <button
                key={att.id}
                type="button"
                onClick={() => trigger(att.postType)}
                className="inline-flex items-center gap-1.5 rounded-md border-[0.5px] border-border bg-paper px-3 py-1.5 text-[12.5px] text-ink-2 transition-colors hover:bg-secondary hover:text-ink"
              >
                <Icon className="size-3.5" strokeWidth={1.5} />
                {att.label}
              </button>
            )
          })}
        </div>

        {/* ── Footer ──────────────────────────────────────────── */}
        <div className="mt-5 flex items-center justify-between gap-3 border-t-[0.5px] border-border px-6 py-4">
          <p className="font-mono text-[10.5px] uppercase tracking-[0.1em] text-ink-4">
            Saved as draft · just now
          </p>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => trigger('TEXT')}
              className="rounded-md border-[0.5px] border-border bg-paper px-4 py-1.5 text-[12.5px] text-ink-2 transition-colors hover:bg-secondary"
            >
              Save draft
            </button>
            <button
              type="button"
              onClick={() => trigger('TEXT')}
              className="inline-flex items-center gap-1.5 rounded-md bg-ink px-4 py-1.5 text-[12.5px] font-medium text-paper transition-colors hover:bg-ink/90"
            >
              <FileText className="size-3.5" strokeWidth={1.5} />
              Publish note
            </button>
          </div>
        </div>
      </section>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="flex max-h-[90vh] max-w-xl flex-col gap-0 overflow-hidden p-0">
          <DialogHeader className="shrink-0 border-b border-border px-5 py-4">
            <DialogTitle className="text-base font-medium">
              {startType === 'REEL'
                ? 'New reel'
                : startType === 'VOICE_POST'
                  ? 'New voice post'
                  : startType === 'EMBEDDED'
                    ? 'New media post'
                    : 'New note'}
            </DialogTitle>
          </DialogHeader>
          <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
            <PostComposer
              bare
              key={startType}
              initialType={startType}
              initialVisibility={visibility}
              onPosted={(created) => {
                onPosted?.(created)
                setOpen(false)
              }}
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
})
