import { cn } from '@/lib/utils'

export function BrandMark({ className }) {
  return (
    <span
      className={cn(
        'font-display grid h-full w-full place-items-center text-[1.1em] leading-none tracking-[-0.04em]',
        className,
      )}
      aria-hidden
    >
      IRC
    </span>
  )
}

export function BrandWordmark({ className, size = 'md' }) {
  const sizes = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-3xl',
    xl: 'text-5xl',
  }
  return (
    <span
      className={cn(
        'font-display inline-flex items-baseline leading-none tracking-[-0.04em]',
        sizes[size] ?? sizes.md,
        className,
      )}
    >
      <span>IRC</span>
      <span className="ml-[0.1em] inline-block h-[0.22em] w-[0.22em] translate-y-[-0.05em] rounded-full bg-current" />
    </span>
  )
}
