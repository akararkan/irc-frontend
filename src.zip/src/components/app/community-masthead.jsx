import { useAuth } from '@/features/auth/auth-context'
import { useNotifications } from '@/features/notifications/notifications-context'
import { cn } from '@/lib/utils'
import { getFullName } from '@/lib/format'

// Editorial home greeting: mono date eyebrow, big serif "Good evening, X.",
// italic serif subtitle. No banner, no ornaments — just typography.
export function CommunityMasthead({ className }) {
  const { user } = useAuth()
  const { unreadCount } = useNotifications()

  const today = new Date()
  const dateLine = today
    .toLocaleDateString(undefined, {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    })
    .toUpperCase()
    .replace(',', ' ·')

  const first = firstName(user)
  const greeting = `${timeGreeting(today)}, ${first ? first : 'friend'}.`

  return (
    <header className={cn('mb-2 pb-1', className)}>
      <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-4">
        {dateLine}
      </p>
      <h1 className="font-display mt-2 text-[34px] font-medium leading-[1.05] tracking-[-0.02em] text-ink sm:text-[40px]">
        {greeting}
      </h1>
      <p className="font-display mt-2 max-w-[60ch] text-[15.5px] italic leading-[1.55] text-ink-3">
        {unreadCount > 0
          ? `${unreadCount} new ${unreadCount === 1 ? 'note' : 'notes'} from people you follow.`
          : 'A quiet desk — start reading, or write a note of your own.'}
      </p>
    </header>
  )
}

function firstName(user) {
  if (!user) return ''
  const first = (user.fname ?? user.firstName ?? '').trim()
  if (first) return first
  const full = getFullName(user)
  if (full) return full.split(/\s+/)[0]
  return ''
}

function timeGreeting(date) {
  const h = date.getHours()
  if (h < 5) return 'Late night'
  if (h < 12) return 'Good morning'
  if (h < 17) return 'Good afternoon'
  return 'Good evening'
}
